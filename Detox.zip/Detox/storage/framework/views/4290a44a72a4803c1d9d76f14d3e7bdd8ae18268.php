<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/SV_detox.css"/>
    <title>Mon suivi Detox</title>
   
</head>

<body>
   <nav>
    <h1 >Votre suivi detox</h1>
    <div class="onglets">
    <a href="/">Home</a>
    <a href="/details">Videos</a>
    <a href="/category">Commander</a>
   </div>
   </nav>

   <header style="background-image: url('https://img.freepik.com/free-photo/studio-portrait-attractive-fitness-couple-holds-barbell-dumbbells-sit-wooden-box-dark-grey-background_613910-16339.jpg?w=360');">
    <span class="white-hero-text">
            <div class="header-text">
        <h1>Pack Detox</h1>
        <h4>La meilleure solution pour perdre le poid et éluminer les toxines</h4>
        <!-- <h4>Votre solution pour sentir bien et detoxifier Votre corps </h4> -->
        <button>Parcourir</button>
    </div>
    </span>

</header>
   <section class="main" id="products">
       <div class="content">
           <div class="card">
               <div class="left">
                   <h1>Le pack Detox</h1>
                   <p>Le programme Détox permet d'éliminer les toxines, de purifier l'organisme en 9 jours.il vous aide également à établir des bases durables qui vous aideront à bien gérer votre poids.</p>
               </div>

               <div class="right">
                   <img src="images/Detox.jpg" alt="">
               </div>
           </div>
           <section class="pd" id="petit-dej">
            <div class="ftor">
             <h1>le jour 1 jusqua le jour 2</h1>
             <div class="go">
             <h3>le petit-dejeuner</h3>
             </div>
            </div>

         </section>

           <div class="card">
            <div class="left">
                <h1>la pulpe d'aloeverat avec ProB</h1>
                <p>Prenez seulement 30ml du aloeverat stablilise<br><br>
                   Apres 20 min prenez une capsule du pro B avec verre d'eau
                </p>
            </div>

            <div class="rightf">
                <img src="images/pulpe2.jpg" alt=""><img src="images/Pro-B.jpg" alt="">
            </div>
          </div>


          <div class="card">
            <div class="left">
                <h1>sport</h1>
                <p>30minut des mouvement sportif ou bien la marche</p>
            </div>

            <div class="right">
                <img src="images/sport.jpg" alt="">
            </div>
          </div>


          <!-- div pour un titre -->
          <div class="pt-repa">
            <h3>Casse-Croute</h3>

          </div>


          <div class="card">
            <div class="left">
                <h1>Ultra lite</h1>
                <p>Apres le sport ou bien la marche vous prenez 300ml du Ultra lite mixer avec l'eau  </p>
            </div>

            <div class="righth">
                <img src="images/shaker_c9.jpg" alt=""><img src="images/Ultra Lite2.jpg" alt="">
            </div>
          </div>

          <div class="djj">
              <h3>Le dejeuner</h3>
          </div>

          <div class="card">
            <div class="left">
                <h1>la pulpe d'aloeverat avec une sachet du super greens</h1>
                <p>Prenez  30ml du aloeverat stablilise <br>
                    Prenez cette sachet  du super greens avec l'eau et mixer le dans la bouteille

                </p>

            </div>

            <div class="righth">
                <img src="images/pulpe2.jpg" alt=""><img src="images/sachet superG.jpg" alt="">
            </div>
          </div>

          <div class="pt-repa">
            <h3>Casse-Croute</h3>
            </div>

            <div class="card">
                <div class="left">
                    <h1>Ultra lite</h1>
                    <p> Prenez 300ml du Ultra lite mixer avec l'eau </p>
                </div>

                <div class="righth">
                    <img src="images/shaker_c9.jpg" alt=""><img src="images/Ultra Lite2.jpg" alt="">
                </div>
             </div>

            <div class="djj">
                <h3>Le diner</h3>
            </div>

             <div class="card">
                <div class="left">
                    <h1>la pulpe d'aloeverat avec ProB</h1>
                    <p>Prenez seulement 30ml du aloeverat stablilise<br><br>
                       Prenez une capsule du pro B avec un verre d'eau
                    </p>
                </div>

                <div class="rightf">
                    <img src="images/pulpe2.jpg" alt=""><img src="images/Pro-B.jpg" alt="">
                </div>
              </div>

              <div class="Srr">
                <h3>le soir</h3>
            </div>
            <div class="card">
                <div class="left">
                    <h1></h1>
                    <p>Le soir, buvez au moins 250ml d'aeu</p>
                </div>

                <div class="right">
                <!-- ici le code d'image -->
                </div>
            </div>
            <section class="pd" id="petit-dej">
                <div class="ftor">
                 <h1>le jour 3 jusqua le jour 9</h1>
                 <div class="go">
                 <h3>le petit-dejeuner</h3>
                 </div>
                </div>
            </section>

            <div class="card">
                <div class="left">
                    <h1>la pulpe d'aloeverat avec ProB</h1>
                    <p>Prenez seulement 30ml du aloeverat stablilise<br><br>
                       Apres 20 min prenez une capsule du pro B avec verre d'eau
                    </p>
                </div>

                <div class="rightf">
                    <img src="images/pulpe2.jpg" alt=""><img src="images/Pro-B.jpg" alt="">
                </div>
              </div>


              <div class="card">
                <div class="left">
                    <h1>sport</h1>
                    <p>30minut des mouvement sportif ou bien la marche</p>
                </div>

                <div class="right">
                    <img src="images/sport.jpg" alt="">
                </div>
              </div>


              <div class="pt-repa">
                <h3>Casse-Croute</h3>
              </div>

              <div class="card">
                <div class="left">
                    <h1>Ultra lite</h1>
                    <p>Apres le sport ou bien la marche vous prenez 300ml du Ultra lite mixer avec l'eau  </p>
                </div>

                <div class="righth">
                    <img src="images/shaker_c9.jpg" alt=""><img src="images/Ultra Lite2.jpg" alt="">
                </div>
              </div>

              <div class="djj">
                <h3>Le dejeuner</h3>
            </div>

            <div class="card">
              <div class="left">
                  <h1>la pulpe d'aloeverat avec une sachet du super greens</h1>
                  <p>Prenez  30ml du aloeverat stablilise <br>
                    et apret vous prenez un plat complet Comme une salade et un steck du poulet<br>
                      en fin Prenez cette sachet  du super greens avec un vert d'eau
                  </p>

              </div>

              <div class="righth">
                  <!-- ajouter une image poue un plat -->
                   <img src="images/pulpe2.jpg" alt=""><img src="images/sachet superG.jpg" alt="">

              </div>
            </div>

              <div class="pt-repa">
                <h3>Casse-Croute</h3>
              </div>

              <div class="card">
                <div class="left">
                    <h1>Ultra lite</h1>
                    <p>  prenez vous 300ml du Ultra lite mixer avec l'eau  </p>
                </div>

                <div class="righth">
                    <img src="images/shaker_c9.jpg" alt=""><img src="images/Ultra Lite2.jpg" alt="">
                </div>
              </div>

              <div class="djj">
                <h3>Le diner</h3>
            </div>

             <div class="card">
                <div class="left">
                    <h1>la pulpe d'aloeverat avec ProB</h1>
                    <p>Prenez seulement 30ml du aloeverat stablilise<br>
                       Prenez une capsule du pro B avec un verre d'eau<br>
                       Prenez sachet  du super greens avec un vert d'eau
                    </p>
                </div>

                <div class="rightf" style="padding-top: 40px;">
                    <img src="images/pulpe2.jpg" alt=""><img src="images/Pro-B.jpg" alt=""><img src="images/sachet superG.jpg" alt="">
                </div>
              </div>

              <div class="Srr">
                <h3>le soir</h3>
            </div>
            <div class="card">
                <div class="left">
                    <h1></h1>
                    <p>Le soir, buvez au moins 250ml d'aeu</p>
                </div>

                <div class="right">
                <!-- ici le code d'image -->
                </div>
            </div>
       </div>
</section>


       <footer style="background-color: #808080; color: #ffffff; padding: 20px;">
        <div style="text-align: center;">
          <h3>Contact Information</h3>
          <p>
            <strong>Progress Experts</strong><br>
            47 BD LALLA YACOUT 5eme Etage Center D'affaire Liberte, Casablanca, Maroc, 20090<br>
            Phone: +212 770015301<br>
            Email: ouaazizmohamed@gmail.com
          </p>
          <p>
            &copy; 2023 Progress Express. à votre service.
          </p>
        </div>
      </footer>

  

</body>
</html><?php /**PATH C:\xamppp\htdocs\Detox\resources\views/projet_detox.blade.php ENDPATH**/ ?>