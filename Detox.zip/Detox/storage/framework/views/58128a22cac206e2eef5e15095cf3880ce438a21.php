<div class="dlabnav">
    <div class="dlabnav-scroll">
        <ul class="metismenu" id="menu">
            <li class="nav-label first">Main Menu</li>
            <li><a class="has-arrow" href="/index" aria-expanded="false">
                    <i class="la la-home"></i>
                    <span class="nav-text"><a href="/index">Dashboard</a></span>
                </a>
            </li>
         
            <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">
                    <i class="la la-users"></i>
                    <span class="nav-text">Commandes</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="<?php echo e(route('allinscription')); ?>">All Commandes</a></li>
                </ul>
            </li>

            <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">
                    <i class="la la-users"></i>
                    <span class="nav-text">Admins</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="<?php echo e(route('alluser')); ?>">All Admins</a></li>
                </ul>
            </li>
        
        </li>
        </ul>
    </div>
</div>
<?php /**PATH C:\xamppp\htdocs\Detox\resources\views/dash/sidebar.blade.php ENDPATH**/ ?>