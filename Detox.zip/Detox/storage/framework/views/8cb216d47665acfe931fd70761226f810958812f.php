<div class="footer">
    <div class="copyright">
        <p>Copyright © Designed &amp; Developed by <a href="#" target="_blank">SYKWEB</a> 2020</p>
    </div>
</div><?php /**PATH C:\xamppp\htdocs\Detox\resources\views/dash/footer.blade.php ENDPATH**/ ?>