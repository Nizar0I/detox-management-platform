<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detox</title>
    <link rel="stylesheet" href="css/category.css">
</head>
<body>
    <nav>
        <h1>Votre suivi detox</h1>
        <div class="onglets">
            <a href="/">Home</a>
            <!-- <a href="products">suivi</a:> -->
            <a href="/details">Videos</a>
            <a href="/category">Commander</a>
        </div>
    </nav>
    <section>
        <h1>Commander votre programme</h1>
        <div class="card">
            <img class="product-img" src="images/Detox.jpg" alt="">
            <div class="product-info">
                <h1>Pack Detox</h1>
                <p>8 articles</p>
                <p class="price">1400,00DH</p>
                <button onclick="addToCart()"><a href="/registration">Commander</a></button>
            </div>
        </div>
    </section>
    
    <footer style="background-color: #808080; color: #ffffff; padding: 20px;">
        <div style="text-align: center;">
          <h3>Contact Information</h3>
          <p>
            <strong>Progress Experts</strong><br>
            47 BD LALLA YACOUT 5eme Etage Center D'affaire Liberte, Casablanca, Maroc, 40000<br>
            Phone: +212 770015301<br>
            Email: ouaazizmohamed@gmail.com
          </p>
          <p>
            &copy; 2023 Progress Express. à votre service.
          </p>
        </div>
      </footer>

    <script src="script.js"></script>
</body>
</html>
<?php /**PATH C:\xamppp\htdocs\Detox\resources\views/category.blade.php ENDPATH**/ ?>