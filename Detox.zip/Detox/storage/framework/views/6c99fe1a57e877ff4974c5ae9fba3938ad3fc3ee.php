
<?php $__env->startSection('body-content'); ?>
    <div class="content-body">
        <!-- row -->
        <div class="container-fluid">

            <div class="row page-titles mx-0">
                <div class="col-sm-6 p-md-0">
                    <div class="welcome-text">
                        <h4>All Admins</h4>
                    </div>
                </div>
                <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0);">All Admins</a></li>
                    </ol>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <div class="row tab-content">
                        <div id="list-view" class="tab-pane fade active show col-lg-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">All Admins</h4>
                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                        data-bs-target="#addnew" data-bs-whatever="@mdo">+ Add new</button>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <?php if(session()->has('message')): ?>
                                            <div class="alert alert-danger">
                                                <?php echo e(session()->get('message')); ?>

                                            </div>
                                        <?php endif; ?>
                                        <table id="example3" class="display" style="min-width: 845px">
                                            <thead>
                                                <tr>
                                                    <th>Nom</th>
                                                    <th>Prenom</th>
                                                    <th>Email</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($user->nom); ?></td>
                                                        <td><?php echo e($user->prenom); ?></td> 
                                                        <td><?php echo e($user->email); ?></td>
                                                        <td>
                                                            <button type="button" value="<?php echo e($user->id); ?>" class="btn btn-sm btnedit btn-success">
                                                                <i class="la la-pencil">
                                                                </i>
                                                            </button>
                                                            <form method="POST" action="<?php echo e(route('deleteuser', ['id' => $user->id])); ?>"
                                                                id="delete_form<?php echo e($loop->iteration); ?>" class="d-none">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                            </form>
                                                            <button class="btn btn-sm btn-danger sweet-confirm"
                                                                form="delete_form<?php echo e($loop->iteration); ?>"
                                                                data-form-id="delete_form<?php echo e($loop->iteration); ?>">
                                                                <i class="la la-trash-o"
                                                                    data-form-id="delete_form<?php echo e($loop->iteration); ?>">
                                                                </i>
                                                            </button>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="addnew" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">New Admin</h5>
                </div>
                <div class="modal-body">
                    <form method="POST" action="<?php echo e(route('storeUser')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="update_nom" class="col-form-label">Nom : </label>
                            <input type="text" min="1" class="form-control" id="update_nom" name="nom">
                        </div>
                        <div class="mb-3">
                            <label for="update_prenom" class="col-form-label">prenom : </label>
                            <input type="text" min="1" class="form-control" id="update_prenom" name="prenom">
                        </div>
                        <div class="mb-3">
                            <label for="update_email" class="col-form-label">Email : </label>
                            <input type="text" min="1" class="form-control" id="update_email" name="email">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Add</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    
    <div class="modal fade" id="update" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Update Classe</h5>
                </div>
                <div class="modal-body">
                    <form id="form_update" method="POST" action="#">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="mb-3">
                            <label for="recipient-name" class="col-form-label">NOM : </label>
                            <input type="text" class="form-control" id="nom" name="nom">
                        </div>
                        <div class="mb-3">
                            <label for="recipient-name" class="col-form-label">prenom : </label>
                            <input type="text" class="form-control" id="prenom" name="prenom">
                        </div>
                        <div class="mb-3">
                            <label for="recipient-name" class="col-form-label">email : </label>
                            <input type="text" class="form-control" id="email" name="email">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-success">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        $(document).on('click', '.btnedit', function() {
            var id = $(this).val();
            var to = "/editUser/update/";
            var updateForm = $('#form_update');
            
            // Vérifier si le formulaire de mise à jour existe
            if (updateForm.length === 0) {
                console.error("Le formulaire de mise à jour n'existe pas.");
                return;
            }

            $('#update').modal('show');

            // Vérifier que l'URL de mise à jour a un ID valide
            if (!id) {
                console.error("ID d'administrateur invalide.");
                return;
            }

            // Modifier l'action du formulaire de mise à jour avec l'URL correcte
            updateForm.prop("action", to + id);

            $.ajax({
                type: "GET",
                url: "/edit_user/" + id,
                success: function(user) {
                    // Vérifier que les données de l'administrateur sont valides
                    if (!user || !user.nom || !user.prenom || !user.email) {
                        console.error("Données d'administrateur invalides.");
                        return;
                    }

                    // Remplir le formulaire de mise à jour avec les données de l'administrateur
                    $('#nom').val(user.nom);
                    $('#prenom').val(user.prenom);
                    $('#email').val(user.email);
                },
                error: function(xhr, status, error) {
                    console.error("Erreur lors de la récupération des données de l'administrateur.");
                    console.error(error);
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dash.blanck-page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppp\htdocs\Detox\resources\views/user/alluser.blade.php ENDPATH**/ ?>