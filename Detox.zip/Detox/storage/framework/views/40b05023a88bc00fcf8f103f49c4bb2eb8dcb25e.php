
<?php $__env->startSection('body-content'); ?>
    <div class="content-body">
        <!-- row -->
        <div class="container-fluid">

            <div class="row page-titles mx-0">
                <div class="col-sm-6 p-md-0">
                    <div class="welcome-text">
                        <h4>All Registrations</h4>
                    </div>
                </div>
                <div class="col-sm-6 p-md-0 justify-content-sm-end mt-2 mt-sm-0 d-flex">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0);">All Registrations</a></li>
                    </ol>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <div class="row tab-content">
                        <div id="list-view" class="tab-pane fade active show col-lg-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">All Inscriptions</h4>
                                    <!-- <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                        data-bs-target="#addnew" data-bs-whatever="@mdo">+ Add new</button> -->
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <?php if(session()->has('message')): ?>
                                            <div class="alert alert-danger">
                                                <?php echo e(session()->get('message')); ?>

                                            </div>
                                        <?php endif; ?>
                                        <table id="example3" class="display" style="min-width: 845px">
                                            <thead>
                                                <tr>
                                                    <th>Nom</th>
                                                    <th>Prenom</th>
                                                    <th>Email</th>
                                                    <th>Adresse</th>
                                                    <th>tel</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($registration->nom); ?></td>
                                                        <td><?php echo e($registration->prenom); ?></td> 
                                                        <td><?php echo e($registration->email); ?></td>
                                                        <td><?php echo e($registration->adresse); ?></td>
                                                        <td><?php echo e($registration->tel); ?></td>
                                                        <td>
                                                            <button type="button" value="<?php echo e($registration->id); ?>" class="btn btn-sm btnedit btn-success">
                                                                <i class="la la-pencil">
                                                                </i>
                                                            </button>
                                                            <form method="POST" action="<?php echo e(route('deleteinscription', ['id' => $registration->id])); ?>"
                                                                id="delete_form<?php echo e($loop->iteration); ?>" class="d-none">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                            </form>
                                                            <button class="btn btn-sm btn-danger sweet-confirm"
                                                                form="delete_form<?php echo e($loop->iteration); ?>"
                                                                data-form-id="delete_form<?php echo e($loop->iteration); ?>">
                                                                <i class="la la-trash-o"
                                                                    data-form-id="delete_form<?php echo e($loop->iteration); ?>">
                                                                </i>
                                                            </button>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="update" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Update Classe</h5>
                </div>
                <div class="modal-body">
                    <form id="form_update" method="POST" action="#">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="mb-3">
                            <label for="recipient-name" class="col-form-label">NOM : </label>
                            <input type="text" class="form-control" id="nom" name="nom">
                        </div>
                        <div class="mb-3">
                            <label for="recipient-name" class="col-form-label">prenom : </label>
                            <input type="text" class="form-control" id="prenom" name="prenom">
                        </div>
                        <div class="mb-3">
                            <label for="recipient-name" class="col-form-label">email : </label>
                            <input type="text" class="form-control" id="email" name="email">
                        </div> <div class="mb-3">
                            <label for="recipient-name" class="col-form-label">adresse : </label>
                            <input type="text" class="form-control" id="adresse" name="adresse">
                        </div> <div class="mb-3">
                            <label for="recipient-name" class="col-form-label">tel : </label>
                            <input type="number" class="form-control" id="tel" name="tel">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-success">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $(document).on('click', '.btnedit', function() {
                var id = $(this).val();
                var to = "/editInscription/update/";
                $('#update').modal('show');
                $('#form_update').prop("action", to + id);
                $.ajax({
                    type: "GET",
                    url: "/edit_inscription/" + id,
                    success: function(registration) {
                        $('#nom').val(registration.nom);
                        $('#prenom').val(registration.prenom);
                        $('#email').val(registration.email);
                        $('#adresse').val(registration.adresse);
                        $('#tel').val(registration.tel);
                    }
                })
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom-scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dash.blanck-page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppp\htdocs\Detox\resources\views/inscription/allinscription.blade.php ENDPATH**/ ?>