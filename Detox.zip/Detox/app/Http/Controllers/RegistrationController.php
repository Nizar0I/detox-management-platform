<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Registration;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Hash;

class RegistrationController extends Controller
{
    public function create(){
        $registration = Registration::all();

        return view('registration',compact('registration'));
    }

    public function store(Request $request){
        // store registration
        $registration = new Registration();
        $registration->nom = $request->nom;
        $registration->prenom = $request->prenom;
        $registration->email = $request->email;
        $registration->adresse = $request->adresse;
        $registration->tel = $request->tel;
        $registration->save();
        return redirect('/')->with('success', 'Room deleted successfully.');   
    }

    public function showall()
    {
        $registrations = Registration::all();
        return view('inscription.allinscription', compact('registrations'));
    }
    
    public function edit($id){
        $registration = Registration::find($id);
        return $registration;
    }

    public function update(Request $request, $id){
        $registration = Registration::find($id);
        $registration->update($request->all());
        return redirect()->route('allinscription');
    }

    public function destroy($id)
    {
        $registration = Registration::find($id);
        $registration->delete();
        return redirect()->route('allinscription')->with('success', 'Room deleted successfully.');
    }

}