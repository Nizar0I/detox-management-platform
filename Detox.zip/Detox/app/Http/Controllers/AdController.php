<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Admin;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use RealRashid\SweetAlert\Facades\Alert;
class AdController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
            $roles = Role::all();
            $to = route('storeadmin');
            $title = 'Ajouter Admin';
            return view('Admin.add_admin',compact('roles','to','title'));
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
          // store user
          $admin = new Admin();
          $admin->email = $request->prenom . $request->nom . '@admin.ma';
          $admin->password = hash::make($request->prenom . $request->nom);
          $admin->nom = $request->nom;
          $admin->prenom = $request->prenom;
          $admin->cin = $request->cin;
          $admin->adresse = $request->adresse;
          $admin->tel = $request->tel;
          $admin->gender = $request->gender;
          $admin->dateNaissance = $request->dateNaissance;
          $admin->description = $request->description;
          $admin->save();
          return redirect('/'); 
          }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function showall(){
        $registration = Registration::all();
        return view('registration.allregistration',compact('registration'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Admin $admin)
    {
        //
        $admin = admin::find($admin->id);
        $to = route('updateadmin', ['admin' => $admin->id]);
        $title = 'Modifier Admin';
        return view('Admin.add_admin', compact( 'to', 'title', 'admin'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Admin $admin, Request $request)
    {
        //
        $admin->update($request->all());
        return redirect()->route('alladmin');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $admin = Admin::find($id);
        $admin->delete();
        return redirect()->route('alladmin')->with('success', 'admin deleted successfully.');
    }

    public function profile($id){
        $admin = Admin::find($id);
        return view('Admin.profileadmin',compact('admin'));
    }
}
