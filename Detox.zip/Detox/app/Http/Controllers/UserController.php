<?php

namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function create(){
        $user = User::all();

        return view('user.alluser',compact('user'));
    }

    public function store(Request $request){
        // store user
        $user = new User();
        $user->nom = $request->nom;
        $user->prenom = $request->prenom;
        $user->email = $request->email;
        $user->save();
        return redirect('/allUser');   
    }

    public function showall()
    {
        $users = User::all();
        return view('user.alluser', compact('users'));
    }
    
    public function edit($id){
        $user = User::find($id);
        return $user;
    }

    public function update(Request $request, $id){
        $user = User::find($id);
        $user->update($request->all());
        return redirect()->route('alluser');
    }


    public function destroy($id)
    {
        $user = User::find($id);
        $user->delete();
        return redirect()->route('alluser')->with('success', 'Room deleted successfully.');
    }
}
