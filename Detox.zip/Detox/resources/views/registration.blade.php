<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
	<style>
		body {
            margin-top: 10%;
			font-family: Arial, sans-serif;
		}


		.wrapper {
			max-width: 400px;
			margin: 0 auto;
			padding: 20px;
			background-color: #f5f5f5;
			border-radius: 5px;
		}

		.title {
			font-size: 24px;
			font-weight: bold;
			margin-bottom: 20px;
			text-align: center;
		}

		.form {
			display: grid;
			grid-gap: 15px;
		}

		.inputfield label {
			display: block;
			margin-bottom: 5px;
			font-weight: bold;
		}

		.inputfield input {
			width: 95%;
			padding: 10px;
			border: 1px solid #ccc;
			border-radius: 4px;
		}

		.inputfield .btn {
			padding: 10px 20px;
			background-color: #4CAF50;
			color: white;
			border: none;
			border-radius: 4px;
			cursor: pointer;
			font-weight: bold;
            width: 100%;
		}

		.inputfield .btn:hover {
			background-color: #45a049;
		}
	</style>
</head>
<body>
<form action="/storeRegisstration" method="post" enctype="multipart/form-data">
	@csrf
	<div class="wrapper">
		<div class="title">
		  Inserer Votre Information:
		</div>
		<div class="form">
		   <div class="inputfield">
			  <label>Nom</label>
			  <input type="text" class="input" value="{{(isset($registrartion))? $registrartion->nom : ''}}" name="nom">
		   </div>  
			<div class="inputfield">
			  <label>Prenom</label>
			  <input type="text" class="input" value="{{(isset($registrartion))? $registrartion->prenom : ''}}" name="prenom">
		   </div>    
			<div class="inputfield">
			  <label> Adresse Email</label>
			  <input type="text" class="input" value="{{(isset($registrartion))? $registrartion->email : ''}}" name="email" >
		   </div> 
           <div class="inputfield">
			  <label> Adresse</label>
			  <input type="text" class="input" value="{{(isset($registrartion))? $registrartion->adresse : ''}}" name="adresse">
		   </div> 
		  <div class="inputfield">
			  <label>Numéro de telephone</label>
			  <input type="text" class="input" value="{{(isset($registrartion))? $registrartion->tel : ''}}" name="tel">
		   </div> 
		  <div class="inputfield">
			<input type="submit" value="Register" class="btn">
		  </div>
		</div>
	</div>
</form>
</body>
</html>