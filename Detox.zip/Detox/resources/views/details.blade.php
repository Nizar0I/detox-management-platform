<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/details.css">
</head>
<body>
    <nav>
        <h1>Votre suivi detox</h1>
        <div class="onglets">
        <a href="/">Home</a>
        <a href="/details">Videos</a>
            <a href="/category">Commander</a>
       </div>
       </nav>


    <section class="section-video">
        <h1 style="font-size:31px; font-weight: 600 ;">Vous pouvez trouver plus d'informations dans cette vidéo</h1>
        <video width="640" height="480" controls>
            <source src="images/details-video.mp4" type="video/mp4">
            
        </video>
        <h1 style="font-size:31px; font-weight: 600 ; padding-top: 3%;">Vous pouvez trouver plus d'informations dans cette vidéo on francais</h1>
        <video width="640" height="480" controls>
            <source src="images/fr-details-video.mp4" type="video/mp4">
            Your browser does not support the video tag.
        </video>
    </section>


    <footer style="background-color: #808080; color: #ffffff; padding: 20px;">
        <div style="text-align: center;">
          <h3>Contact Information</h3>
          <p>
            <strong>Progress Experts</strong><br>
            47 BD LALLA YACOUT 5eme Etage Center D'affaire Liberte, Casablanca, Maroc, 40<br>
            Phone: +212 770015301<br>
            Email: ouaazizmohamed@gmail.com
          </p>
          <p>
            &copy; 2023 Progress Express. à votre service.
          </p>
        </div>
      </footer>
</body>
</html>