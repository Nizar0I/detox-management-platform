<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RegistrationController;
use App\Http\Controllers\UserController;




/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', function () {
    return view('projet_detox');
});
Route::get('/category', function () {
    return view('category');
});
Route::get('/index', function () {
    return view('index');
});
Route::get('/welcome', function () {
    return view('welcome');
});



Route::get('/details', function () {
    return view('details');
});
Route::get('/profileregistration', function () {
    return view('profileregistration');
});
Route::get('/suivi', function () {
    return view('suivi');
});

Route::get('/login', function () {
    return view('login');
});


//Start student controller
Route::get('/registration',[RegistrationController::class,'create'])->name('registration');
Route::get('/allInscription',[RegistrationController::class,'showall'])->name('allinscription');
Route::post('/storeRegisstration',[RegistrationController::class,'store'])->name('storeRegistration');
Route::put('/editInscription/update/{id}', [RegistrationController::class, 'update'])->name('updateinscription');
Route::delete('/deleteInscription/{id}', [RegistrationController::class, 'destroy'])->name('deleteinscription');
Route::get('/edit_inscription/{id}',[RegistrationController::class,'edit']);
//End student controller
Route::get('/user',[UserController::class,'create'])->name('user');
Route::get('/allUser',[UserController::class,'showall'])->name('alluser');
Route::post('/storeUser',[UserController::class,'store'])->name('storeUser');
Route::put('/editUser/update/{id}', [UserController::class, 'update'])->name('updateuser');
Route::delete('/deleteUser/{id}', [UserController::class, 'destroy'])->name('deleteuser');
Route::get('/edit_user/{id}',[UserController::class,'edit']);


Auth::routes();

